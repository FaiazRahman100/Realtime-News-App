//
//  Constants.swift
//  faiaz_rahman_30024_mid2
//
//  Created by Faiaz Rahman on 19/1/23.
//

import Foundation

class Constants {
    static let key1 = "89e9414e695f403fa02e9b8d190e0984"
    static let key2 = "1500c23728894ce5b8af1672274618f3"
    static let key3 = "5d223675b4f14734b2b44c3bba51b796"
    static let key4 = "3cb4201c7a74405894b73b4fd117d719"
    static let initialCategory = "all"
    static let categoryIcons = ["newspaper","briefcase","sparkles.tv","newspaper","cross.vial","testtube.2","gamecontroller","waveform.path.ecg.rectangle"]
    
    static let newsCategories = ["All", "Business","Entertainment","General","Health","Science","Sports","Technology"]
    static let initialPageCount = [1,1,1,1,1,1,1,1]
    static let pageCounterKey = "pageCounter"
    static let lastUpdateKey = "lastUpdate"
    
}
