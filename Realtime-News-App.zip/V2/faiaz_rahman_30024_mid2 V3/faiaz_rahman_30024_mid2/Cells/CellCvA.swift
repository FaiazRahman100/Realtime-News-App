//
//  CellCvA.swift
//  faiaz_rahman_30024_mid2
//
//  Created by Faiaz Rahman on 14/1/23.
//

import UIKit

class CellCvA: UICollectionViewCell {
    
    @IBOutlet weak var cVLabel: UILabel!
}
